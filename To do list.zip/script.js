let i=0;
let j=false;
function taskEnter(){
    let task = document.querySelector('#text');

   //kreiranje dugmeta
    /*let newCheckBox = document.createElement('input');
    newCheckBox.type= 'checkbox';
    newCheckBox.className='cb'+i;
    newCheckBox.setAttribute('id','checkbox');
    document.querySelector('.container').appendChild(newCheckBox);*/

    //kreiranje teksta
    let newElement = document.createElement('button');
    newElement.className='el'+i;
    newElement.setAttribute('id','element');
    newElement.innerText= task.value;
    newElement.addEventListener('click',() => {
            if (newElement.id == 'element') {
                newElement.setAttribute('id','elementc');
            }  
            else{
                newElement.setAttribute('id','element'); 
            }
    })
    document.querySelector('.container').appendChild(newElement);


    //kreiranje dugmeta
    let newButton = document.createElement('button');
    newButton.className='re'+i;
    newButton.innerText= 'X';
    newButton.setAttribute('id','button');
    newButton.addEventListener('click',() => {
        remover(element,button);
    })
    document.querySelector('.container').appendChild(newButton);
    let element = document.querySelector('.el'+i);
    let button = document.querySelector('.re'+i);
    i++;
}

function remover(element,button){
    element.remove();
    button.remove();
}


